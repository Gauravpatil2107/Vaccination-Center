package com.cg.eis.repository;

import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.cg.eis.entities.VaccinationCenter;
import com.cg.eis.service.VaccinationCenterService;

@SpringBootTest
public class VaccinationCenterServiceTest {
	
	@Autowired
	private VaccinationCenterService vaccinationCenterService;
	
	@Test
	public void getAllVaccineCenters(){
	List<VaccinationCenter> cen=vaccinationCenterService.getAllVaccineCenters();
	}
	 
	@Test
	 public void addVaccineCenter() {
		VaccinationCenter vnc=new VaccinationCenter(101,"centername","address","city","state","pincode",null,null);
		vaccinationCenterService.addVaccineCenter(vnc);

	}
	
	@Test
	 public void updateVaccineCenter() {
		VaccinationCenter vnc=new VaccinationCenter(102,"centername","address","city","state","pincode",null,null);
		vaccinationCenterService.updateVaccineCenter(vnc);

	}
	
	@Test
	 public void deleteVaccineCenter() {
		VaccinationCenter vnc=new VaccinationCenter(101,"centername","address","city","state","pincode",null,null);
		vaccinationCenterService.deleteVaccineCenter(vnc);

	}
	
	@Test
	 public void getVaccineCenter() {
		VaccinationCenter vnc=vaccinationCenterService.getVaccineCenter(101);
		

	}
	
	
}