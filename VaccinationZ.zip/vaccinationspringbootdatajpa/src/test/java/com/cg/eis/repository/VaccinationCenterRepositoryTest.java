package com.cg.eis.repository;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.cg.eis.entities.VaccinationCenter;
import com.cg.eis.repository.VaccinationCenterRepository;

@SpringBootTest
class VaccinationCenterRepositoryTest {

	@Autowired
	 private  VaccinationCenterRepository vaccinationCenterRepository;
	 
	@Test
	 public void saveVaccinationCenter() {
		VaccinationCenter vnc=new VaccinationCenter(101,"centername","address","city","state","pincode",null,null);
		vaccinationCenterRepository.save(vnc);
		
	}
}
