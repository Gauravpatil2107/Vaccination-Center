package com.cg.eis.service;

import java.util.List;

import com.cg.eis.entities.Appointment;

public interface AppointmentService {
	public Appointment addAppointment(Appointment app);
	public Appointment updateAppointment(Appointment app);
	public void deleteAppointment(Appointment app);
	public Appointment getAppointment(long bookingid);
	public List<Appointment> getAllAppointment();
}
