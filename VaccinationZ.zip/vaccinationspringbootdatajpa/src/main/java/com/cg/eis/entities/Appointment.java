package com.cg.eis.entities;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table
public class Appointment {
	
	@Id
     private long bookingid;
	
	
	
     public Appointment() {
		super();
		// TODO Auto-generated constructor stub
	}
	private long mobileno;
     private boolean bookingstatus;
     
     
     
     
    public Appointment(long bookingid, long mobileno, boolean bookingstatus) {
		super();
		this.bookingid = bookingid;
		this.mobileno = mobileno;
		this.bookingstatus = bookingstatus;
	}
	/* @OneToOne
     private VaccinationCenter vnc;*/
     
     
	public long getBookingid() {
		return bookingid;
	}
	public void setBookingid(long bookingid) {
		this.bookingid = bookingid;
	}
	public long getMobileno() {
		return mobileno;
	}
	public void setMobileno(long mobileno) {
		this.mobileno = mobileno;
	}
	public boolean isBookingstatus() {
		return bookingstatus;
	}
	public void setBookingstatus(boolean bookingstatus) {
		this.bookingstatus = bookingstatus;
	}
	/*public VaccinationCenter getVnc() {
		return vnc;
	}
	public void setVnc(VaccinationCenter vnc) {
		this.vnc = vnc;
	}*/


	@Override
	public String toString() {
		return "Appointment [bookingid=" + bookingid + ", mobileno=" + mobileno + ", bookingstatus=" + bookingstatus
				+ "]";
	}
	
	
}
