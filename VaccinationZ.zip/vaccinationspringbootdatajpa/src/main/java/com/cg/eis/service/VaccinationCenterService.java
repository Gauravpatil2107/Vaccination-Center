package com.cg.eis.service;

import java.util.List;

import org.springframework.stereotype.Component;

import com.cg.eis.entities.VaccinationCenter;

@Component
public interface VaccinationCenterService {
	public VaccinationCenter addVaccineCenter(VaccinationCenter center);
	public VaccinationCenter updateVaccineCenter(VaccinationCenter center);
	public void deleteVaccineCenter(VaccinationCenter center);
	public VaccinationCenter getVaccineCenter(int code);
	public List<VaccinationCenter> getAllVaccineCenters();

}
