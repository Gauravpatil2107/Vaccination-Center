package com.cg.eis.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.cg.eis.entities.VaccinationCenter;

@Repository
public interface VaccinationCenterRepository extends JpaRepository<VaccinationCenter, Integer>{
	
	/*public VaccinationCenter addVaccineCenter(VaccinationCenter center);
	public VaccinationCenter updateVaccineCenter(VaccinationCenter center);
	public boolean deleteVaccineCenter(VaccinationCenter center);
	public VaccinationCenter getVaccineCenter(int centerid);
	public List<VaccinationCenter> getAllVaccineCenters();*/

}
