package com.cg.eis.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.eis.entities.Appointment;
import com.cg.eis.repository.AppointmentRepository;

@Service("appointmentService")
public class AppointmentSeviceImpl implements AppointmentService {
	
	@Autowired
	public AppointmentRepository appointmentrepository;

	@Override
	public Appointment addAppointment(Appointment app) {
		return appointmentrepository.save(app);
	}

	@Override
	public Appointment updateAppointment(Appointment app) {
		return appointmentrepository.save(app);
	}

	@Override
	public void deleteAppointment(Appointment app) {
		
		appointmentrepository.delete(app);
	}

	@Override
	public Appointment getAppointment(long bookingid) {
		
		return appointmentrepository.getById(bookingid);
	}

	@Override
	public List<Appointment> getAllAppointment() {
		
		return appointmentrepository.findAll();
	}

}
