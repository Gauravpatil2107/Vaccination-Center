package com.cg.eis.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.cg.eis.entities.Appointment;
import com.cg.eis.entities.VaccinationCenter;

@Repository
public interface AppointmentRepository  extends JpaRepository<Appointment, Long> {
	/* public Appointment addAppointment(Appointment app);
	public Appointment updateAppointment(Appointment app);
	public boolean deleteAppointment(Appointment app);
	public Appointment getAppointment(long bookingid);
	public List<Appointment> getAllAppointment();*/

}
